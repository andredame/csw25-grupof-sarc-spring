package br.com.sarc.csw.core.exception;

public class RecursoIndisponivelException extends RuntimeException {
    public RecursoIndisponivelException(String message) {
        super(message);
    }
}
