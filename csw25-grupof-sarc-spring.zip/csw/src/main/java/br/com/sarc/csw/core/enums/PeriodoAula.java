package br.com.sarc.csw.core.enums;

public enum PeriodoAula {
    AB , CD ,JK ,LM ,NP;
}
