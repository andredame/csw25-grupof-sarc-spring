package br.com.sarc.csw.modules.predio.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class PredioResumoDTO {
    private Long id;
    private String nome;
}
