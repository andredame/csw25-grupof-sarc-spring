package br.com.sarc.csw.modules.recurso.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TipoRecursoDTO {
    private Long id;
    private String nome;
    
}
